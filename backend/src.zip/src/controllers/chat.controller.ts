import OpenAI from 'openai';
import { Request, Response } from 'express';

class ChatController {
    private openai: OpenAI;
    
    constructor() {
        this.openai = new OpenAI({
        apiKey: process.env.OPENAI_API_KEY,
        });
    }
    
    async askQuestion(req: Request, res: Response) {
        console.log('askQuestion', req.body);
        const { question, userId } = req.body;
        console.log('question', question);
        try {
        if (!question || !userId) {
            throw new Error('no question or userId provided');
        }
    
        const response = await this.openai.chat.completions.create({
            model: 'gpt-3.5-turbo',
            messages: [{ role: 'user', content: question }],
        });
    
        res.status(200).json(response.choices[0].message.content);
        } catch (error: any) {
        res.status(400).json({ message: error.message });
        }
    }
}
export const chatController = new ChatController();