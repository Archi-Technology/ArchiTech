import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Grid,
  Typography,
  Paper,
  Container,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  IconButton
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import Lottie from 'lottie-react';
import createAnimation from '../../assets/lotties/create.json';
import openAnimation from '../../assets/lotties/open.json';
import {
  getAllProjects,
  createProject,
} from '../../services/projectService';

interface Project {
  _id: string;
  name: string;
  lastEdited?: string;
  data?: Record<string, any>;
}

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [hovered, setHovered] = useState<string | null>(null);
  const navigate = useNavigate();

  const fetchProjects = async () => {
    try {
      const data = await getAllProjects();
      setProjects(data);
    } catch (err) {
      console.error('Error fetching projects', err);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  const handleCreateProject = async () => {
    try {
      await createProject('New Project');
      await fetchProjects();
      navigate('/home');
    } catch (err) {
      console.error('Error creating project', err);
    }
  };

  return (
    <Container>
      <Typography variant="h4" style={{ color: '#3b1ae0' }} className="mb-6 mt-4 text-center">
        Recent Projects
      </Typography>

      <Box display="flex" justifyContent="center" gap={4} mb={4}>
        <div
          style={{ textAlign: 'center', cursor: 'pointer' }}
          onClick={handleCreateProject}
          onMouseEnter={() => setHovered('create')}
          onMouseLeave={() => setHovered(null)}
        >
          <Lottie
            animationData={createAnimation}
            loop={false}
            autoplay={hovered === 'create'}
            style={{ width: 80, height: 80 }}
          />
          <Typography variant="subtitle1" style={{ color: '#3b1ae0', fontWeight: 500 }}>
            Create New Project
          </Typography>
        </div>

        <div
          style={{ textAlign: 'center', cursor: 'pointer' }}
          onClick={() => setOpenDialog(true)}
          onMouseEnter={() => setHovered('open')}
          onMouseLeave={() => setHovered(null)}
        >
          <Lottie
            animationData={openAnimation}
            loop={false}
            autoplay={hovered === 'open'}
            style={{ width: 80, height: 80 }}
          />
          <Typography variant="subtitle1" style={{ color: '#3b1ae0', fontWeight: 500 }}>
            Open Existing Project
          </Typography>
        </div>
      </Box>

      <Grid container spacing={3}>
        {projects.map((project) => (
          <Grid item xs={12} sm={6} md={4} key={project._id}>
            <Paper
              elevation={3}
              onClick={() => navigate(`/project/${project._id}`)}
              style={{
                backgroundColor: '#f4f2ff',
                padding: '20px',
                borderRadius: '12px',
                textAlign: 'center',
                cursor: 'pointer',
                transition: 'transform 0.2s ease-in-out',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.03)')}
              onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
            >
              <Typography variant="h6" style={{ color: '#3b1ae0' }}>{project.name}</Typography>
              <Typography variant="caption" color="textSecondary">
                Last edited: {project.lastEdited ? new Date(project.lastEdited).toLocaleDateString() : 'N/A'}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Dialog open={openDialog} onClose={() => setOpenDialog(false)}>
        <DialogTitle>
          Open Existing Project
          <IconButton onClick={() => setOpenDialog(false)} style={{ position: 'absolute', right: 8, top: 8 }}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers>
          <Typography variant="body1">Select an existing project from the list above.</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpenDialog(false)} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Container>
  );
}
