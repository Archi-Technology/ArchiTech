export function TechBackground() {
  return (
    <div className="fixed inset-0 -z-10 bg-white bg-circuit-pattern">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/50 to-purple-50/50"></div>
    </div>
  )
}
