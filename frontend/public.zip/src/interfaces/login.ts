import { EneterModes } from "../enums/login";

export interface IEnterModeOption {
    key: EneterModes
    title: string;
}