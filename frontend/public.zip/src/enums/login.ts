export enum EneterModes {
    LOGIN = 'LOGIN',
    REGISTER = 'REGISTER'
}
