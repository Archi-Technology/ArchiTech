type TokenInfo = {
    _id: string
}

export default TokenInfo;