export interface IAuthTokens {
  accessToken: string;
  refreshToken: string;
}


